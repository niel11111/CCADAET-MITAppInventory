#|
$JSON
{"authURL":[],"YaVersion":"237","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"32","Uuid":"0","Title":"Screen1","AppName":"Week3_Teoxon","Theme":"AppTheme.Light.DarkActionBar"}}
|#